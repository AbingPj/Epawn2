<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class itemCategoryController extends Controller
{
    public function uploadItem(){}
}
